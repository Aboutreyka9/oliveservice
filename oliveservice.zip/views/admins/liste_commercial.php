<div class="card mt-2 bg_light">
    <div class="card-header">
        <div class="table_row_header">
            <div class="table_row_header_left">
                <h4 class="text-upper"> <i class="fa fa-list"></i> &nbsp; Liste des Commerciaux</h4>
            </div>
            <div class="table_row_header_right">
                <button class="btn btn-primary"> <i class="fa fa-print"></i> &nbsp; <span class="text_button text-uppercase">Imprimer</span></button>
                <button class="btn btn-info btn_utilisateur_addModal"> <i class="fa fa-plus-circle fa-2"></i> &nbsp; <span class="text_button text-uppercase">Enregistrer commercial</span></button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive" id="sexion_user">
            <table id="data-table-commercial" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>EMAIL</th>
                        <th>NOM</th>
                        <th>PRENOMS</th>
                        <th>CONTACT</th>
                        <th>FONCTION</th>
                        <th>STATUT</th>
                        <th>OPTION</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" data-backdrop="static" id="user-modal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" id="userModalLabel"><i class="fa fa-user-circle"></i> &nbsp; <span class="text-uppercase">Formulaire d'enregistrement</span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 data-modal"></div>
                </div>
            </div>
            <div class="modal-footer"></div>
        </div>
    </div>
</div>
